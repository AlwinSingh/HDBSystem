package src.service;

public class ApplicationService {
}
