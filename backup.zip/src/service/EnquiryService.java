package src.service;

public class EnquiryService {
}
