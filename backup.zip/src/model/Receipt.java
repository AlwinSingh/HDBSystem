package src.model;

public class Receipt {
}
