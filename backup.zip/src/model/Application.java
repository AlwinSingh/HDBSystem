package src.model;

public class Application {
}
