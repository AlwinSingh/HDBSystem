package src.model;

public class Enquiry {
}
